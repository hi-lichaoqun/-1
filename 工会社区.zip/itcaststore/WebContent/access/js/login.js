


     //点击验证码时实现验证码的重新加载
	function changeImg(img) {
		img.src = "ValiImg?time=" + new Date().getTime();
	}
	
	//在登录时对用户信息进行验证
	function checkInfo(){
		var username = document.getElementById("username");
		var password = document.getElementById("password");
		var userNode = document.getElementById("usernamenull");
		var userInputNode = document.getElementsByTagName("input");
		
		if(username.value==""){
			userNode.innerHTML = "<font color='red' size ='4px'>用户名不能为空！</font>";
			userInputNode[0].style.border=' 2px solid red';
				userInputNode[0].onblur = function(){
					userInputNode[0].style.border='2px solid green';
			}
			return false;
		}
		else{
			userNode.innerHTML = "";
		}
		if(password.value==""){
			userNode.innerHTML =  "<font color='red' size ='4px'>用户密码不能为空！</font>";
			userInputNode[1].style.border=' 2px solid red';
			userInputNode[1].onblur = function(){
				userInputNode[1].style.border='2px solid green';
			}
			return false;
		}else{
			userNode.innerHTML = "";
		}
		
		return true;
	}
	
	//点击注册按钮进行跳转到注册页面
	 function jump(){
		 window.location.href="regist.jsp";
	 }
	 
	