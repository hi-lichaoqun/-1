//在登录时对用户信息进行验证
	function checkInfo(){
		var username = document.getElementById("username");
		var password = document.getElementById("password");
		var repassword = document.getElementById("repassword");
		var mail = document.getElementById("mail");
		var useNode = document.getElementById("usernamenull");
		var userInputNode = document.getElementsByTagName("input");
		//验证邮箱的正则表达式
		var regex = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
		
		if(username.value==""){
			useNode.innerHTML = "<font color='red' size ='4px'>用户名不能为空！</font>";
			userInputNode[0].style.border=' 2px solid red';
				userInputNode[0].onblur = function(){
					userInputNode[0].style.border='2px solid green';
			}
			return false;
		}
		else{
			useNode.innerHTML = "";
		}
		if(password.value==""){
			useNode.innerHTML =  "<font color='red' size ='4px'>用户密码不能为空！</font>";
			userInputNode[1].style.border=' 2px solid red';
			userInputNode[1].onblur = function(){
				userInputNode[1].style.border='2px solid green';
			}
			return false;
		}else{
			useNode.innerHTML = "";
		}
		if(password.value !==repassword.value){
			useNode.innerHTML =  "<font color='red' size ='4px'>两次密码不一致！</font>";
			userInputNode[1].style.border=' 2px solid red';
			userInputNode[2].style.border=' 2px solid red';
			userInputNode[1].onblur = function(){
				userInputNode[1].style.border='2px solid green';
			}
			userInputNode[2].onblur = function(){
				userInputNode[2].style.border='2px solid green';
			}
			return false;
		}else{
			useNode.innerHTML = "";
		}
		if(mail.value==""||!regex.test(mail.value)){
			var usernameNode = document.getElementById("username");
			useNode.innerHTML = "<font color='red' size ='4px'>邮箱格式不正确</font>";
			userInputNode[3].style.border=' 2px solid red';
			userInputNode[3].onblur = function(){
				userInputNode[3].style.border='2px solid green';
			}
			return false;
		}
		else{
			useNode.innerHTML = "";
		}
		
		return true;
	}
	
	/*//当用户名存在时接收从后台发送过来的异常信息，通过EL表达式接收，对用户进行提示
	window.onload = function(){
		var exceptionMsg = "${requestScope.msg}";
		if(exceptionMsg!="")
			alert(exceptionMsg);
	}*/