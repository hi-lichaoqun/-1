package cn.itcast.itcaststore.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ArrayListHandler;

import cn.itcast.itcaststore.utils.DataSourceUtils;

/**
 * Servlet implementation class search
 */
public class search extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public search() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());

		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String searchInfo = request.getParameter("searchInfo");
		String username = request.getParameter("username");
		String sqll = "select title from tiezi where title like ?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		 
		 
			List<String> ls=new ArrayList<>();	
			try{
		    List<Object[]> l=new ArrayList<>();
		 	l=null;
			l = runner.query(sqll, new ArrayListHandler(), "%"+searchInfo+"%");
		 
			 System.out.print(l);
			if (l.size() > 0) {

				 

				int lg = l.size();

				for (int i=0;i<lg;i++) {

					 Object[] o=l.get(lg-i-1); 

					ls.add(o[0].toString());

				}
				request.setAttribute("username",username);
				request.setAttribute("ttttt", ls);
				request.getRequestDispatcher("/search.jsp").forward(request, response);
			} else {
				request.setAttribute("usererrorinfo", "不存在违法记录");
				request.getRequestDispatcher("/search.jsp").forward(request, response);
			}
		} catch (Exception e) {

			response.getWriter().append("fail");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
