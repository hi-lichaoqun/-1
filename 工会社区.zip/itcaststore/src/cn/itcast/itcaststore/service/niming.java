package cn.itcast.itcaststore.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;

import cn.itcast.itcaststore.utils.DataSourceUtils;

/**
 * Servlet implementation class niming
 */
public class niming extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public niming() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().append("Served at: ").append(request.getContextPath());

		String username = request.getParameter("ftname");
		String p = request.getParameter("content");
		String m = request.getParameter("username");
		//response.getWriter().append(username+p);
		String sql = "insert into tiezi(title,content) values(?,?)";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		try{
		
		int row = runner.update(sql, username,p);
		if(row>0){
			request.setAttribute("username", m);
			//request.setAttribute("tl",ls);
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		 }
		}catch(Exception e){
			
		}
		 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		 
	}

}
